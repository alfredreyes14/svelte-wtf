<script>
	import * as prismicH from '@prismicio/helpers';

	export let slice;
</script>

<h2 class="layout">{prismicH.asText(slice.primary.text)}</h2>

<style>
	h2 {
		margin-bottom: 5vw;
		margin-top: 5vw;
	}
</style>
